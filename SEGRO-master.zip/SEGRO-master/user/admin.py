from django.contrib import admin
from .models import Segro_User
# Register your models here.

admin.site.register(Segro_User)
