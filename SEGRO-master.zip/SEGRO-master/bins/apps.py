from django.apps import AppConfig


class BinsConfig(AppConfig):
    name = 'bins'
