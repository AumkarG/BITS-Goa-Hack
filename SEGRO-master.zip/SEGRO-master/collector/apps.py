from django.apps import AppConfig


class CollectorConfig(AppConfig):
    name = 'collector'
